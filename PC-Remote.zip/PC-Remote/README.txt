PC REMOTE
Shut down, lock, restart and watch your Windows PC from your phone, protected by your fingerprint.

INSTALL (3 steps)
  1. Extract (unzip) this folder: right-click the zip > Extract All.
  2. Double-click  START HERE.bat  and click Yes.
       - If Windows SmartScreen warns, click "More info" then "Run anyway".
       - It installs Docker Desktop and Tailscale for you if you don't have them,
         signs you in, and sets everything up. First time: about 10 minutes.
       - It may ask you to restart once. It carries on by itself afterwards.
       - It may open a Tailscale page and ask you to click "Enable HTTPS" (first time only).
  3. A setup page opens on your PC with your link, a QR code and your PIN. Follow the
     3 steps on it. They tick off by themselves as you go.

YOU NEED
  - Windows 10 or 11 and an internet connection
  - A phone with a fingerprint or face unlock set up
  - A free Tailscale account (sign in with Google, Microsoft, Apple or GitHub)

WHERE IS MY LINK?
  - On the setup page (it opens at the end of Setup)
  - The "PC Remote setup" shortcut on your desktop
  - Or on this PC, go to  http://localhost:8765/setup
  It looks like  https://your-pc-name.tailXXXX.ts.net  and only works for devices signed in
  to your Tailscale account. Once the app is installed on your phone you don't need the link.

IF SOMETHING GOES WRONG
  - "PC offline" in the app: check Tailscale is on, on your phone, and the PC is signed in to Windows.
  - "PC helper not running": wait a minute, or open START HERE again.
  - Anything else: open START HERE again. It is safe to run as many times as you like.

REMOVE EVERYTHING: double-click Uninstall.bat  (Docker and Tailscale stay installed)
