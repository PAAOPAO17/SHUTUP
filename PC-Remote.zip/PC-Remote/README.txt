PC REMOTE
Shut down, lock, restart and watch your computer from your phone, protected by your fingerprint.

WORKS WITH
  Your computer:  Windows 10/11  or  Mac (macOS 12 or newer)
  Your phone:     iPhone/iPad  or  Android  (any phone with a fingerprint or face unlock)
  Any mix works, for example iPhone -> Windows, Android -> Mac.

INSTALL ON WINDOWS
  1. Extract (unzip) this folder: right-click the zip > Extract All.
  2. Double-click  START HERE.bat  and click Yes.
       - If Windows SmartScreen warns, click "More info" then "Run anyway".
       - It installs Docker Desktop and Tailscale for you if you don't have them.
         It may ask you to restart once and carries on by itself afterwards.

INSTALL ON MAC
  1. Double-click the zip to extract it.
  2. Right-click  START HERE (Mac).command  > Open > Open.
       (If Terminal says "permission denied", open Terminal and run:  bash "START HERE (Mac).command"  )
  3. Follow the messages in the window. It installs Docker Desktop and Tailscale if you
     use Homebrew; otherwise it opens their download pages and waits for you.
  4. macOS asks for permissions for "PC Remote Helper". Click Allow, and in System Settings >
     Privacy & Security > Screen Recording, turn on "PC Remote Helper" (needed for View screen).

THEN (both systems)
  A setup page opens on your computer with your link, a QR code and your setup PIN. Follow
  the 3 steps on it. They tick off by themselves as you go.
  The first time, Tailscale may ask you to click "Enable HTTPS" on a web page (one time only).

YOU NEED
  - An internet connection
  - A free Tailscale account (sign in with Google, Microsoft, Apple or GitHub)
  - A phone with a fingerprint or face unlock set up

WHERE IS MY LINK?
  - On the setup page (it opens at the end of Setup)
  - The "PC Remote setup" shortcut on your Desktop
  - Or on the computer itself, go to  http://localhost:8765/setup
  It looks like  https://your-computer.tailXXXX.ts.net  and only works for devices signed in
  to your Tailscale account. Once the app is installed on your phone you don't need the link.

MAC NOTES
  - Lock uses your Mac's own lock, so set System Settings > Lock Screen > "Require password
    after screen saver begins or display is turned off" to "Immediately".
  - Shut down and Restart ask macOS nicely, like the Apple menu does. A program with unsaved
    work can stop it. (On Windows they are forced.)
  - If View screen shows only your wallpaper, Screen Recording isn't allowed yet (see step 4).

IF SOMETHING GOES WRONG
  - "PC offline" in the app: check Tailscale is on, on your phone, and the computer is logged in.
  - "PC helper not running": wait a minute, or open START HERE again.
  - Anything else: open START HERE again. It is safe to run as many times as you like.

REMOVE EVERYTHING
  Windows: Uninstall.bat      Mac: Uninstall (Mac).command
  (Docker and Tailscale stay installed)
