PC REMOTE - easy setup (Windows)

Before you start (one time):
  1. Install Docker Desktop:  https://www.docker.com/products/docker-desktop/
     Open it once, accept the terms, and wait until it says "Running".
  2. Install Tailscale on this PC and on your phone:  https://tailscale.com/download
     Sign in to both with the SAME account.

Then:
  3. Unzip this folder, double-click  Setup.bat  and click Yes when Windows asks.
     (If Windows SmartScreen warns, click "More info" then "Run anyway".)
  4. A setup page opens on your PC. It shows your link, a QR code and your setup PIN.
     Nothing to edit. Open the link on your phone (Tailscale on), hold the power button,
     enter the PIN once and register your fingerprint.

Find the setup page again any time: the "PC Remote setup" shortcut on your desktop,
or http://localhost:8765/setup (only works on this PC).

To remove everything later: double-click Uninstall.bat
