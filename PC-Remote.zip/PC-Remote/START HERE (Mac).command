#!/bin/bash
cd "$(dirname "$0")" && bash ./setup-mac.sh
