@echo off
title PC Remote setup
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
