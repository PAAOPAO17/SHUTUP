// Plain text overlay for PC Remote on macOS: no background, clicks pass through, sits above everything.
// Usage: osascript -l JavaScript overlay.js "message text"   (the helper stops it by ending this process)
ObjC.import('AppKit');

function run(argv) {
  var text = argv.join(' ');
  var app = $.NSApplication.sharedApplication;
  app.setActivationPolicy(1);                       // accessory: no Dock icon, never takes focus

  var vis = $.NSScreen.mainScreen.visibleFrame;
  var maxW = Math.floor(vis.size.width * 0.8);
  var fontSize = text.length < 40 ? 48 : (text.length < 120 ? 34 : 24);
  var font = $.NSFont.boldSystemFontOfSize(fontSize);

  function makeLabel(color, x, y, w, h) {
    var l = $.NSTextField.alloc.initWithFrame($.NSMakeRect(x, y, w, h));
    l.setStringValue($(text));
    l.setEditable(false); l.setSelectable(false); l.setBezeled(false); l.setDrawsBackground(false);
    l.setAlignment(1);                              // centered
    l.setLineBreakMode(0);                          // wrap words
    l.setMaximumNumberOfLines(0);
    l.setFont(font); l.setTextColor(color);
    return l;
  }

  // measure the wrapped text, then size the window to fit it
  var probe = makeLabel($.NSColor.whiteColor, 0, 0, maxW, 100);
  var fit = probe.cell.cellSizeForBounds($.NSMakeRect(0, 0, maxW, 100000));
  var tw = Math.min(maxW, Math.ceil(fit.width) + 4), th = Math.ceil(fit.height) + 4;
  var w = tw + 40, h = th + 40;

  var x = vis.origin.x + (vis.size.width - w) / 2;
  var y = vis.origin.y + (vis.size.height - h) / 2;
  var win = $.NSWindow.alloc.initWithContentRectStyleMaskBackingDefer($.NSMakeRect(x, y, w, h), 0, 2, false);
  win.setOpaque(false);
  win.setBackgroundColor($.NSColor.clearColor);
  win.setHasShadow(false);
  win.setIgnoresMouseEvents(true);                  // clicks go straight through
  win.setLevel(1000);                               // above everything
  win.setCollectionBehavior(1 | 16 | 256);          // every Space, also over full-screen apps

  // thin dark outline (eight offset copies) so the text reads on any wallpaper, then the white text
  var offs = [[-2, 0], [2, 0], [0, -2], [0, 2], [-2, -2], [2, -2], [-2, 2], [2, 2]];
  offs.forEach(function (o) { win.contentView.addSubview(makeLabel($.NSColor.blackColor, 20 + o[0], 20 + o[1], tw, th)); });
  win.contentView.addSubview(makeLabel($.NSColor.whiteColor, 20, 20, tw, th));

  win.orderFrontRegardless();
  app.run();                                        // stays until the helper ends this process
}
