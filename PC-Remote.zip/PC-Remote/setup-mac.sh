#!/bin/bash
# PC Remote - one-click setup for macOS. Open "START HERE (Mac).command" (it runs this file).
# Installs/starts Docker Desktop and Tailscale, then sets everything up.

ROOT="$(cd "$(dirname "$0")" && pwd)"
HOME_DIR="$HOME/.pc-remote"
APPDIR="$HOME_DIR/app"
HELPERDIR="$HOME_DIR/helper"
TRIG="$HOME_DIR/trigger"
APPLET="$HOME_DIR/PC Remote Helper.app"
PLIST="$HOME/Library/LaunchAgents/com.pcremote.helper.plist"
export PATH="$PATH:/usr/local/bin:/opt/homebrew/bin:/Applications/Docker.app/Contents/Resources/bin"
n=0; total=7

bold() { printf '\033[1m%s\033[0m\n' "$*"; }
step() { n=$((n+1)); echo; printf '\033[36m[%s/%s] %s\033[0m\n' "$n" "$total" "$*"; }
ok()   { printf '\033[32m  OK %s\033[0m\n' "$*"; }
warn() { printf '\033[33m  !  %s\033[0m\n' "$*"; }
say()  { echo "     $*"; }
fail() { echo; printf '\033[31m  X  %s\033[0m\n' "$*"; echo; read -r -p "Press Enter to close" _; exit 1; }
jget() {   # read a value out of JSON using macOS's built-in JavaScript: jget "<json>" Self.DNSName
  osascript -l JavaScript -e 'function run(a){var o=JSON.parse(a[0]);var v=a[1].split(".").reduce(function(x,k){return x==null?x:x[k]},o);return v==null?"":String(v)}' "$1" "$2" 2>/dev/null
}

[ "$(uname)" = "Darwin" ] || fail "This installer is for macOS. On Windows, use START HERE.bat."
[ -f "$ROOT/files/server.py" ] || fail "The 'files' folder is missing. Unzip the whole PC-Remote folder first, then open START HERE (Mac) again."

echo; bold "  PC Remote setup (Mac)"
echo "  This sets everything up. The first time takes about 10 minutes."
echo "  macOS will ask for a few permissions along the way. Allow them."

# ===== 1. Docker =====
step "Docker Desktop (runs the website on your Mac)"
if ! command -v docker >/dev/null 2>&1 && [ ! -d /Applications/Docker.app ]; then
  if command -v brew >/dev/null 2>&1; then
    say "Installing Docker Desktop with Homebrew (a few minutes)..."
    brew install --cask docker-desktop || brew install --cask docker
  fi
fi
if ! command -v docker >/dev/null 2>&1 && [ ! -d /Applications/Docker.app ]; then
  open "https://www.docker.com/products/docker-desktop/"
  say "A download page opened. Install Docker Desktop (drag it to Applications)."
  read -r -p "     Press Enter here when it's installed " _
fi
if ! docker info >/dev/null 2>&1; then
  open -a Docker 2>/dev/null
  say "Starting Docker Desktop. If it asks to accept terms or for your password, allow it."
  t=0; while ! docker info >/dev/null 2>&1 && [ $t -lt 300 ]; do sleep 5; t=$((t+5)); done
  docker info >/dev/null 2>&1 || fail "Docker didn't start. Open Docker Desktop, finish its first-run questions, wait until it says Running, then open START HERE (Mac) again."
fi
ok "Docker is running"
say "Tip: in Docker Desktop > Settings > General, keep 'Start Docker Desktop when you sign in' on."

# ===== 2. Tailscale =====
step "Tailscale (the private connection between your phone and this Mac)"
TS=""
find_ts() { for p in "/Applications/Tailscale.app/Contents/MacOS/Tailscale" "/opt/homebrew/bin/tailscale" "/usr/local/bin/tailscale"; do [ -x "$p" ] && TS="$p" && return 0; done; return 1; }
if ! find_ts; then
  if command -v brew >/dev/null 2>&1; then
    say "Installing Tailscale with Homebrew..."
    brew install --cask tailscale-app || brew install --cask tailscale
  fi
fi
if ! find_ts; then
  open "https://tailscale.com/download/mac"
  say "A download page opened. Install Tailscale and open it once."
  read -r -p "     Press Enter here when it's installed " _
  find_ts || fail "Couldn't find Tailscale. Install it, then open START HERE (Mac) again."
fi
open -a Tailscale 2>/dev/null
state=""; t=0; asked=0
while [ $t -lt 360 ]; do
  st=$("$TS" status --json 2>/dev/null); state=$(jget "$st" BackendState)
  [ "$state" = "Running" ] && break
  if [ $asked = 0 ] && { [ "$state" = "NeedsLogin" ] || [ -z "$state" ]; } && [ $t -ge 6 ]; then
    asked=1; say "Click the Tailscale icon in the menu bar (top of the screen), choose Log in, and sign in."
    say "Google, Microsoft, Apple and GitHub all work. Use the same account on your phone."
  fi
  sleep 3; t=$((t+3))
done
[ "$state" = "Running" ] || fail "Tailscale isn't signed in yet. Sign in to it, then open START HERE (Mac) again."
dns=$(jget "$st" Self.DNSName); dns="${dns%.}"
if [ -z "$dns" ]; then open "https://login.tailscale.com/admin/dns"; fail "Tailscale has no name for this Mac. On the page that opened, turn on MagicDNS, then open START HERE (Mac) again."; fi
ok "Tailscale is connected"

# ===== 3. Link =====
step "Creating your private HTTPS link"
published=0
for i in 1 2 3 4 5; do
  out=$("$TS" serve --bg 8765 2>&1); status=$("$TS" serve status 2>&1)
  if echo "$status" | grep -q "https://$dns"; then published=1; break; fi
  warn "Tailscale needs one click from you (only the first time on your account)."
  url=$(echo "$out" | grep -Eo 'https://login\.tailscale\.com/[^ ]+' | head -1)
  open "${url:-https://login.tailscale.com/admin/dns}"
  say "A page just opened. Sign in if it asks, then:"
  say "  - click 'Enable HTTPS' (under 'HTTPS Certificates'), or"
  say "  - click 'Enable' if it offers to turn on Serve."
  read -r -p "     Press Enter here when you've clicked it " _
done
[ $published = 1 ] || fail "Couldn't create the link. Check the page in your browser, then open START HERE (Mac) again."
ok "Your link is ready"

# ===== 4. Files =====
step "Installing PC Remote"
mkdir -p "$APPDIR" "$HELPERDIR" "$TRIG"
for f in server.py index.html setup.html sw.js manifest.webmanifest icon-192.png icon-512.png apple-touch-icon.png Dockerfile; do
  cp "$ROOT/files/$f" "$APPDIR/$f" || fail "Couldn't copy $f"
done
cp "$ROOT/mac/docker-compose.yml" "$APPDIR/docker-compose.yml"
cp "$ROOT/mac/helper.sh" "$ROOT/mac/overlay.js" "$HELPERDIR/"
chmod +x "$HELPERDIR/helper.sh"
ok "Files installed in $HOME_DIR"

# ===== 5. Helper =====
step "Setting up the helper (starts by itself when you log in)"
cat > "$HOME_DIR/helper-applet.applescript" <<APPLESCRIPT
on run
	ensureHelper()
end run
on idle
	ensureHelper()
	return 30
end idle
on ensureHelper()
	try
		do shell script "kill -0 \$(cat '$TRIG/helper.pid' 2>/dev/null) 2>/dev/null || (nohup /bin/bash '$HELPERDIR/helper.sh' >/dev/null 2>&1 &)"
	end try
end ensureHelper
APPLESCRIPT
launchctl bootout "gui/$(id -u)" "$PLIST" 2>/dev/null
[ -f "$TRIG/helper.pid" ] && kill "$(cat "$TRIG/helper.pid")" 2>/dev/null
rm -rf "$APPLET"
osacompile -s -o "$APPLET" "$HOME_DIR/helper-applet.applescript" || fail "Couldn't create the helper app."
defaults write "$APPLET/Contents/Info" LSUIElement -bool true     # no Dock icon
codesign --force --deep -s - "$APPLET" >/dev/null 2>&1
mkdir -p "$HOME/Library/LaunchAgents"
cat > "$PLIST" <<PLISTXML
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
	<key>Label</key><string>com.pcremote.helper</string>
	<key>ProgramArguments</key><array><string>$APPLET/Contents/MacOS/applet</string></array>
	<key>RunAtLoad</key><true/>
	<key>KeepAlive</key><true/>
	<key>LimitLoadToSessionType</key><string>Aqua</string>
</dict></plist>
PLISTXML
launchctl bootstrap "gui/$(id -u)" "$PLIST" 2>/dev/null || launchctl load -w "$PLIST"
sleep 6
if [ -f "$TRIG/helper.pid" ] && kill -0 "$(cat "$TRIG/helper.pid")" 2>/dev/null; then ok "Helper is running and will start when you log in"
else warn "The helper isn't running yet. It retries every 30 seconds. Details: $TRIG/watcher.log"; fi

# ===== 6. Permissions =====
step "Allowing the helper to control this Mac"
echo probe > "$TRIG/action.txt"      # makes macOS ask for permission now, while you're watching
say "macOS may now show pop-ups from 'PC Remote Helper'. Click Allow / OK on them:"
say "  - 'wants to control System Events'  (needed to shut down, restart)"
say "  - 'would like to record your screen' (needed for View screen)"
sleep 4
open "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture" 2>/dev/null
say "System Settings just opened to Screen Recording. Turn ON 'PC Remote Helper'."
say "(If it isn't in the list, click +, press Cmd+Shift+G, paste:  $APPLET  and add it.)"
read -r -p "     Press Enter here when that's done " _
[ -f "$TRIG/helper.pid" ] && kill "$(cat "$TRIG/helper.pid")" 2>/dev/null   # restart so the new permission takes effect
launchctl kickstart -k "gui/$(id -u)/com.pcremote.helper" 2>/dev/null
ok "Helper restarted"

# ===== 7. Website =====
step "Building the website (the first time takes a few minutes)"
( cd "$APPDIR" && docker rm -f pc-remote >/dev/null 2>&1; docker compose up -d --build ) || fail "Docker couldn't build the site. Scroll up for the error message, then open START HERE (Mac) again."
up=0; for i in $(seq 1 30); do curl -fs -m 2 http://127.0.0.1:8765/api/ping >/dev/null 2>&1 && { up=1; break; }; sleep 2; done
[ $up = 1 ] && ok "Website is running" || warn "The website didn't answer yet. Give it a minute, then open the setup page."

pin=$(curl -fs -m 5 http://localhost:8765/api/setup 2>/dev/null); pin=$(jget "$pin" pin)
printf '%s' "https://$dns" | pbcopy 2>/dev/null
cat > "$HOME/Desktop/PC Remote setup.webloc" <<WEBLOC
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict><key>URL</key><string>http://localhost:8765/setup</string></dict></plist>
WEBLOC
open "http://localhost:8765/setup"
echo
printf '\033[32m==================================================\n  ALL SET - finish on your phone\n\n'
echo "  The setup page just opened in your browser. It shows:"
echo "    - a QR code to scan with your phone"
echo "    - your link:  https://$dns   (copied)"
echo "    - your setup PIN:  ${pin:-(on the setup page)}"
echo
echo "  Lost the page? Open 'PC Remote setup' on your Desktop,"
echo "  or go to http://localhost:8765/setup on this Mac."
printf '==================================================\033[0m\n'
echo; read -r -p "Press Enter to close" _
