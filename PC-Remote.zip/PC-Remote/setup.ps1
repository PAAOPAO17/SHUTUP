# PC Remote - one-click setup. Double-click Setup.bat (it runs this file).
$ErrorActionPreference = "Continue"
$Host.UI.RawUI.WindowTitle = "PC Remote setup"

function Pause-Exit($code) { Write-Host ""; Read-Host "Press Enter to close"; exit $code }
function Fail($m) { Write-Host ""; Write-Host "  X  $m" -ForegroundColor Red; Pause-Exit 1 }
function Ok($m)   { Write-Host "  OK $m" -ForegroundColor Green }
function Warn($m) { Write-Host "  !  $m" -ForegroundColor Yellow }
function Step($m) { Write-Host ""; Write-Host "==> $m" -ForegroundColor Cyan }

# --- needs administrator (for the antivirus exclusion and scheduled task) ---
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Start-Process powershell -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

$app  = "C:\pc-remote"
$trig = "C:\pc-remote-trigger"
$src  = Join-Path $PSScriptRoot "files"
if (-not (Test-Path "$src\server.py")) { Fail "The 'files' folder is missing. Unzip the whole PC-Remote folder first, then run Setup again." }

# --- 1. Docker ---
Step "Checking Docker Desktop"
$dockerBin = "$env:ProgramFiles\Docker\Docker\resources\bin"
if (Test-Path $dockerBin) { $env:Path += ";$dockerBin" }
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    Fail "Docker Desktop isn't installed. Get it from https://www.docker.com/products/docker-desktop/ , open it once, then run Setup again."
}
function Test-Docker { docker info 2>&1 | Out-Null; return ($LASTEXITCODE -eq 0) }
if (-not (Test-Docker)) {
    $dd = "$env:ProgramFiles\Docker\Docker\Docker Desktop.exe"
    if (Test-Path $dd) { Start-Process explorer.exe -ArgumentList "`"$dd`"" }   # start it as your normal user, not as admin
    Write-Host "  Starting Docker Desktop (this can take a couple of minutes)..."
    $t = 0; while (-not (Test-Docker) -and $t -lt 240) { Start-Sleep 5; $t += 5 }
    if (-not (Test-Docker)) { Fail "Docker didn't start. Open Docker Desktop, accept its terms, wait until it says Running, then run Setup again." }
}
Ok "Docker is running"
$runKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
if (-not (Get-ItemProperty $runKey -ErrorAction SilentlyContinue)."Docker Desktop") {
    Set-ItemProperty $runKey "Docker Desktop" "`"$env:ProgramFiles\Docker\Docker\Docker Desktop.exe`" -Autostart"
    Ok "Docker Desktop will start when you sign in"
}

# --- 2. Tailscale ---
Step "Checking Tailscale"
$ts = "$env:ProgramFiles\Tailscale\tailscale.exe"
if (-not (Test-Path $ts)) {
    $c = Get-Command tailscale -ErrorAction SilentlyContinue
    if ($c) { $ts = $c.Source } else { Fail "Tailscale isn't installed. Get it from https://tailscale.com/download/windows , sign in, then run Setup again." }
}
$st = $null; $t = 0
while ($t -lt 300) {
    try { $st = (& $ts status --json | Out-String | ConvertFrom-Json) } catch { $st = $null }
    if ($st -and $st.BackendState -eq "Running") { break }
    if ($t -eq 0) { Write-Host "  Waiting for Tailscale. Click its icon near the clock and sign in..." }
    Start-Sleep 3; $t += 3
}
if (-not $st -or $st.BackendState -ne "Running") { Fail "Tailscale isn't signed in. Sign in to it, then run Setup again." }
$dns = ([string]$st.Self.DNSName).TrimEnd(".")
if (-not $dns) { Fail "Tailscale has no name for this PC. Turn on MagicDNS at https://login.tailscale.com/admin/dns and run Setup again." }
Ok "Tailscale is connected as $dns"

Step "Publishing the site over HTTPS"
$published = $false
for ($i = 0; $i -lt 4; $i++) {
    $out = (& $ts serve --bg 8765 2>&1 | Out-String)
    $status = (& $ts serve status 2>&1 | Out-String)
    if ($status -match [regex]::Escape("https://$dns")) { $published = $true; break }
    Write-Host $out
    Warn "Tailscale needs HTTPS turned on once for your account:"
    Write-Host "     1. Open https://login.tailscale.com/admin/dns"
    Write-Host "     2. Make sure MagicDNS is on, then click 'Enable HTTPS'"
    Write-Host "     3. If the text above has a link about enabling Serve, open it and approve"
    Read-Host "     Press Enter here when that's done"
}
if (-not $published) { Fail "Couldn't publish the site over HTTPS. Check the Tailscale steps above, then run Setup again." }
Ok "Your link is https://$dns"

# --- 3. Files ---
Step "Installing the app"
New-Item -ItemType Directory -Force $app, $trig | Out-Null
icacls $trig /grant "Users:(OI)(CI)M" | Out-Null
try { Add-MpPreference -ExclusionPath "$trig\watcher.ps1" -ErrorAction Stop; Ok "Windows Defender allowed the helper script" }
catch { Warn "Couldn't add a Defender exclusion (other antivirus?). If the helper gets blocked, allow $trig\watcher.ps1 in your antivirus." }
Copy-Item "$src\*" $app -Force -Exclude watcher.ps1
Copy-Item "$src\watcher.ps1" "$trig\watcher.ps1" -Force

Ok "Files installed"

# --- 4. Helper auto-start ---
Step "Setting up auto-start of the helper"
$user = (Get-CimInstance Win32_ComputerSystem).UserName
if (-not $user) { $user = "$env:USERDOMAIN\$env:USERNAME" }
$a  = New-ScheduledTaskAction -Execute "conhost.exe" -Argument '--headless powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\pc-remote-trigger\watcher.ps1"'
$t1 = New-ScheduledTaskTrigger -AtLogOn -User $user
$t2 = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 5) -RepetitionDuration (New-TimeSpan -Days 9999)
$s  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Seconds 0) -StartWhenAvailable -MultipleInstances IgnoreNew
$p  = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive
Stop-ScheduledTask -TaskName "PCRemoteWatcher" -ErrorAction SilentlyContinue
Register-ScheduledTask -TaskName "PCRemoteWatcher" -Action $a -Trigger $t1, $t2 -Settings $s -Principal $p -Force | Out-Null
Start-ScheduledTask -TaskName "PCRemoteWatcher"
Start-Sleep 8
if ((Get-ScheduledTask -TaskName "PCRemoteWatcher").State -eq "Running") { Ok "Helper is running" }
else { Warn "The helper isn't running yet. It retries every 5 minutes. If the app later says 'PC helper not running', check $trig\watcher.log" }

# --- 5. Website ---
Step "Building the website (the first time takes a few minutes)"
Push-Location $app
docker rm -f pc-remote 2>&1 | Out-Null
docker compose up -d --build
$code = $LASTEXITCODE
Pop-Location
if ($code -ne 0) { Fail "Docker couldn't build the site. Scroll up for the error message, fix it, then run Setup again." }
$up = $false
for ($i = 0; $i -lt 30; $i++) {
    try { Invoke-WebRequest "http://127.0.0.1:8765/api/ping" -UseBasicParsing -TimeoutSec 2 | Out-Null; $up = $true; break } catch { Start-Sleep 2 }
}
if ($up) { Ok "Website is running" } else { Warn "The website didn't answer yet. Give it a minute, then open the link." }

# --- done ---
$pin = "(shown on the setup page)"
try { $pin = (Invoke-RestMethod "http://localhost:8765/api/setup" -TimeoutSec 5).pin } catch { }
try { Set-Clipboard "https://$dns" } catch { }
try {   # desktop shortcut to the setup page, so the link and PIN are always one click away
    $lnk = (New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path ([Environment]::GetFolderPath("Desktop")) "PC Remote setup.url"))
    $lnk.TargetPath = "http://localhost:8765/setup"; $lnk.Save()
} catch { }
Start-Process explorer.exe "http://localhost:8765/setup"   # opens in your normal browser
Write-Host ""
Write-Host "==================================================" -ForegroundColor Green
Write-Host "  ALL SET" -ForegroundColor Green
Write-Host ""
Write-Host "  Your link :  https://$dns   (copied to clipboard)"
Write-Host "  Setup PIN :  $pin   (needed once, on your phone)"
Write-Host ""
Write-Host "  A setup page just opened in your browser. It shows your link,"
Write-Host "  a QR code and your PIN, and lets you change the PIN."
Write-Host "  Open it any time from the 'PC Remote setup' shortcut on your desktop"
Write-Host "  or at http://localhost:8765/setup"
Write-Host "==================================================" -ForegroundColor Green
Pause-Exit 0
