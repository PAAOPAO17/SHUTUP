# PC Remote - one-click setup. Double-click "START HERE.bat" (it runs this file).
# It installs Docker Desktop and Tailscale if they are missing, then sets everything up.
$ErrorActionPreference = "Continue"
$Host.UI.RawUI.WindowTitle = "PC Remote setup"
$script:n = 0; $total = 6

function Pause-Exit($code) { Write-Host ""; Read-Host "Press Enter to close"; exit $code }
function Fail($m) { Write-Host ""; Write-Host "  X  $m" -ForegroundColor Red; Pause-Exit 1 }
function Ok($m)   { Write-Host "  OK $m" -ForegroundColor Green }
function Warn($m) { Write-Host "  !  $m" -ForegroundColor Yellow }
function Say($m)  { Write-Host "     $m" }
function Step($m) { $script:n++; Write-Host ""; Write-Host "[$($script:n)/$total] $m" -ForegroundColor Cyan }
function Open-Url($u) { try { Start-Process explorer.exe $u } catch { } }

# running straight from inside the zip file does not work: the other files are not extracted
if ($PSScriptRoot -match '\\Temp\\Temp\d+_') {
    Fail "Please extract the folder first: right-click the zip, choose 'Extract All', then open START HERE from the new folder."
}

# --- needs administrator (to install programs, allow the helper in Defender, create the startup task) ---
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Start-Process powershell -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    exit
}

$app  = "C:\pc-remote"
$trig = "C:\pc-remote-trigger"
$src  = Join-Path $PSScriptRoot "files"
if (-not (Test-Path "$src\server.py")) { Fail "The 'files' folder is missing. Extract the whole zip first, then open START HERE again." }

Write-Host ""
Write-Host "  PC Remote setup" -ForegroundColor Green
Write-Host "  This installs everything for you. The first time takes about 10 minutes."
Write-Host "  You may be asked to sign in to Tailscale, and to restart once."

function Install-WithWinget($id) {
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) { return $false }
    winget install -e --id $id --silent --accept-package-agreements --accept-source-agreements
    return ($LASTEXITCODE -eq 0 -or $LASTEXITCODE -eq 3010)   # 3010 = installed, restart needed
}
function Resume-After-Restart($why) {   # continue Setup by itself after a restart
    Warn $why
    Set-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce" "PCRemoteSetup" ('"' + (Join-Path $PSScriptRoot "START HERE.bat") + '"')
    Say "Setup will continue by itself the next time you sign in to Windows."
    if ((Read-Host "     Restart now? (Y/N)") -match '^[Yy]') { Restart-Computer -Force }
    Pause-Exit 0
}

# ===== 1. Docker =====
Step "Docker Desktop (runs the website on your PC)"
$dockerBin = "$env:ProgramFiles\Docker\Docker\resources\bin"
function Find-Docker {
    if ((Test-Path $dockerBin) -and ($env:Path -notlike "*$dockerBin*")) { $env:Path += ";$dockerBin" }
    return [bool](Get-Command docker -ErrorAction SilentlyContinue)
}
function Test-Docker { docker info 2>&1 | Out-Null; return ($LASTEXITCODE -eq 0) }
$justInstalled = $false
if (-not (Find-Docker)) {
    Say "Docker isn't installed. Installing it now (a few minutes)..."
    if (-not (Install-WithWinget "Docker.DockerDesktop")) {
        Open-Url "https://www.docker.com/products/docker-desktop/"
        Fail "Couldn't install Docker automatically. A download page opened: install Docker Desktop, then open START HERE again."
    }
    $justInstalled = $true
    if (-not (Find-Docker)) { Resume-After-Restart "Windows needs a restart to finish installing Docker." }
}
if (-not (Test-Docker)) {
    $dd = "$env:ProgramFiles\Docker\Docker\Docker Desktop.exe"
    if (Test-Path $dd) { Start-Process explorer.exe "`"$dd`"" }   # started as you, not as administrator
    Say "Starting Docker Desktop. If a window asks you to accept the terms, click Accept."
    $t = 0; while (-not (Test-Docker) -and $t -lt 300) { Start-Sleep 5; $t += 5 }
    if (-not (Test-Docker)) {
        if ($justInstalled) { Resume-After-Restart "Windows needs a restart to finish setting up Docker." }
        Fail "Docker didn't start. Open Docker Desktop, accept its terms, wait until it says Running, then open START HERE again."
    }
}
Ok "Docker is running"
$runKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
if (-not (Get-ItemProperty $runKey -ErrorAction SilentlyContinue)."Docker Desktop") {
    Set-ItemProperty $runKey "Docker Desktop" "`"$env:ProgramFiles\Docker\Docker\Docker Desktop.exe`" -Autostart"
    Ok "Docker Desktop will start when you sign in to Windows"
}

# ===== 2. Tailscale =====
Step "Tailscale (the private connection between your phone and this PC)"
$ts = "$env:ProgramFiles\Tailscale\tailscale.exe"
function Find-Ts {
    if (-not (Test-Path $script:ts)) { $c = Get-Command tailscale -ErrorAction SilentlyContinue; if ($c) { $script:ts = $c.Source } }
    return (Test-Path $script:ts)
}
function Get-TsStatus { try { return (& $script:ts status --json | Out-String | ConvertFrom-Json) } catch { return $null } }
if (-not (Find-Ts)) {
    Say "Tailscale isn't installed. Installing it now..."
    if (-not (Install-WithWinget "Tailscale.Tailscale")) {
        Open-Url "https://tailscale.com/download/windows"
        Fail "Couldn't install Tailscale automatically. A download page opened: install it and sign in, then open START HERE again."
    }
    Start-Sleep 5
    if (-not (Find-Ts)) { Fail "Tailscale installed but can't be found yet. Restart your PC, then open START HERE again." }
}
$st = $null; $t = 0; $asked = $false
while ($t -lt 360) {
    $st = Get-TsStatus
    if ($st -and $st.BackendState -eq "Running") { break }
    if ($st -and $st.BackendState -eq "NeedsLogin" -and -not $asked) {
        $asked = $true
        Say "A browser page is opening. Sign in to Tailscale with Google, Microsoft, Apple or GitHub."
        Start-Process -FilePath $ts -ArgumentList "login" -WindowStyle Hidden
    }
    Start-Sleep 3; $t += 3
}
if (-not $st -or $st.BackendState -ne "Running") { Fail "Tailscale isn't signed in yet. Sign in to it (icon near the clock), then open START HERE again." }
$dns = ([string]$st.Self.DNSName).TrimEnd(".")
if (-not $dns) {
    Open-Url "https://login.tailscale.com/admin/dns"
    Fail "Tailscale has no name for this PC. On the page that opened, turn on MagicDNS, then open START HERE again."
}
$acct = ""; try { $uid = [string]$st.Self.UserID; $acct = [string]$st.User.$uid.LoginName } catch { }
Ok "Tailscale is connected"
if ($acct) { Say "Signed in as $acct. Use the same account on your phone." }

# ===== 3. Link =====
Step "Creating your private HTTPS link"
$published = $false
for ($i = 0; $i -lt 5; $i++) {
    $out = (& $ts serve --bg 8765 2>&1 | Out-String)
    $status = (& $ts serve status 2>&1 | Out-String)
    if ($status -match [regex]::Escape("https://$dns")) { $published = $true; break }
    Warn "Tailscale needs one click from you (only the first time on your account)."
    $m = [regex]::Match($out, 'https://login\.tailscale\.com/\S+')
    if ($m.Success) { Open-Url $m.Value.TrimEnd('.', ',', ')') } else { Open-Url "https://login.tailscale.com/admin/dns" }
    Say "A page just opened in your browser. Sign in if it asks, then:"
    Say "  - click 'Enable HTTPS' (look under 'HTTPS Certificates'), or"
    Say "  - click 'Enable' if it offers to turn on Serve."
    Read-Host "     Press Enter here when you've clicked it"
}
if (-not $published) { Fail "Couldn't create the link. Check the page in your browser, then open START HERE again." }
Ok "Your link is ready"

# ===== 4. Files and helper =====
Step "Installing PC Remote"
New-Item -ItemType Directory -Force $app, $trig | Out-Null
icacls $trig /grant "Users:(OI)(CI)M" | Out-Null
try { Add-MpPreference -ExclusionPath "$trig\watcher.ps1" -ErrorAction Stop; Ok "Windows Defender allowed the helper script" }
catch { Warn "Couldn't add a Defender exclusion (another antivirus?). If the helper gets blocked, allow $trig\watcher.ps1 in it." }
Copy-Item "$src\*" $app -Force -Exclude watcher.ps1
Copy-Item "$src\watcher.ps1" "$trig\watcher.ps1" -Force
Ok "Files installed"

$user = (Get-CimInstance Win32_ComputerSystem).UserName
if (-not $user) { $user = "$env:USERDOMAIN\$env:USERNAME" }
$a  = New-ScheduledTaskAction -Execute "conhost.exe" -Argument '--headless powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\pc-remote-trigger\watcher.ps1"'
$t1 = New-ScheduledTaskTrigger -AtLogOn -User $user
$t2 = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 5) -RepetitionDuration (New-TimeSpan -Days 9999)
$s  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Seconds 0) -StartWhenAvailable -MultipleInstances IgnoreNew
$p  = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive
Stop-ScheduledTask -TaskName "PCRemoteWatcher" -ErrorAction SilentlyContinue
Register-ScheduledTask -TaskName "PCRemoteWatcher" -Action $a -Trigger $t1, $t2 -Settings $s -Principal $p -Force | Out-Null
Start-ScheduledTask -TaskName "PCRemoteWatcher"
Start-Sleep 8
if ((Get-ScheduledTask -TaskName "PCRemoteWatcher").State -eq "Running") { Ok "Helper is running and will start with Windows" }
else { Warn "The helper isn't running yet. It retries every 5 minutes. If the app later says 'PC helper not running', see $trig\watcher.log" }

# ===== 5. Website =====
Step "Building the website (the first time takes a few minutes)"
Push-Location $app
docker rm -f pc-remote 2>&1 | Out-Null
docker compose up -d --build
$code = $LASTEXITCODE
Pop-Location
if ($code -ne 0) { Fail "Docker couldn't build the site. Scroll up for the error message, then open START HERE again." }
$up = $false
for ($i = 0; $i -lt 30; $i++) {
    try { Invoke-WebRequest "http://127.0.0.1:8765/api/ping" -UseBasicParsing -TimeoutSec 2 | Out-Null; $up = $true; break } catch { Start-Sleep 2 }
}
if ($up) { Ok "Website is running" } else { Warn "The website didn't answer yet. Give it a minute, then open the setup page." }

# ===== 6. Done =====
Step "Opening your setup page"
$pin = "(on the setup page)"
try { $pin = (Invoke-RestMethod "http://localhost:8765/api/setup" -TimeoutSec 5).pin } catch { }
try { Set-Clipboard "https://$dns" } catch { }
try {   # desktop shortcut, so your link and PIN are always one click away
    $lnk = (New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path ([Environment]::GetFolderPath("Desktop")) "PC Remote setup.url"))
    $lnk.TargetPath = "http://localhost:8765/setup"; $lnk.Save()
} catch { }
Open-Url "http://localhost:8765/setup"
Write-Host ""
Write-Host "==================================================" -ForegroundColor Green
Write-Host "  ALL SET - finish on your phone" -ForegroundColor Green
Write-Host ""
Write-Host "  The setup page just opened in your browser. It shows:"
Write-Host "    - a QR code to scan with your phone"
Write-Host "    - your link:  https://$dns"
Write-Host "    - your setup PIN:  $pin"
Write-Host ""
Write-Host "  Lost the page? Open the 'PC Remote setup' shortcut on your desktop,"
Write-Host "  or go to http://localhost:8765/setup on this PC."
Write-Host "==================================================" -ForegroundColor Green
Pause-Exit 0
