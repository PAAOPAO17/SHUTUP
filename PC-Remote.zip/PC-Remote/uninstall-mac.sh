#!/bin/bash
# PC Remote - removes everything Setup installed on macOS.
export PATH="$PATH:/usr/local/bin:/opt/homebrew/bin:/Applications/Docker.app/Contents/Resources/bin"
PLIST="$HOME/Library/LaunchAgents/com.pcremote.helper.plist"
echo "Removing PC Remote..."
launchctl bootout "gui/$(id -u)" "$PLIST" 2>/dev/null || launchctl unload "$PLIST" 2>/dev/null
[ -f "$HOME/.pc-remote/trigger/helper.pid" ] && kill "$(cat "$HOME/.pc-remote/trigger/helper.pid")" 2>/dev/null
rm -f "$PLIST"
[ -f "$HOME/.pc-remote/app/docker-compose.yml" ] && ( cd "$HOME/.pc-remote/app" && docker compose down -v )
for p in "/Applications/Tailscale.app/Contents/MacOS/Tailscale" "/opt/homebrew/bin/tailscale" "/usr/local/bin/tailscale"; do
  [ -x "$p" ] && { "$p" serve reset; break; }
done
rm -rf "$HOME/.pc-remote" "$HOME/Desktop/PC Remote setup.webloc"
echo
echo "Done. (Docker Desktop and Tailscale were left installed.)"
read -r -p "Press Enter to close" _
